the files in this directory are simple and unadulterated topas scripts.
We build our optimisation examples starting with this folder, which is representative of the way and end user
would itneract with this code. 